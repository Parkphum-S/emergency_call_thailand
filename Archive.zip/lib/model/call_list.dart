class CallLineData {
  String fname = "";
  String name = "";
  String phone = "";
  String image = "";

  CallLineData({
    required this.fname,
    required this.name,
    required this.phone,
    required this.image,
  });
}
