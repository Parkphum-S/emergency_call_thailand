package com.example.emergency_call_thailand

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
